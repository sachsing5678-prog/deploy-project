import{R as o,j as t}from"./index-456RK1po.js";import{F as e}from"./FitnessApp-DJ8ynT-p.js";function n(){const{page:s}=o.useParams();return t.jsx(e,{page:s})}export{n as component};
