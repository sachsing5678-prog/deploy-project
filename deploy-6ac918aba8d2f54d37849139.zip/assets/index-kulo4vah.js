import{j as o}from"./index-456RK1po.js";import{F as p}from"./FitnessApp-DJ8ynT-p.js";const m=()=>o.jsx(p,{page:"dashboard"});export{m as component};
